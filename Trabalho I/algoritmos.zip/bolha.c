#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void ordenar(int V[], int n);

void main() {
 int n, *V;

  printf("Informe quantos números deseja inserir\n");
  scanf(" %d", &n);
  V = (int *)malloc((n+1) * sizeof(int));
  V[0] = INT_MIN;

  for (int i = 1; i <= n; i++) {
    printf("Entre com um número:\n");
    scanf(" %d", &V[i]);
  }

  ordenar(V, n);
  printf("END\n");

}

void ordenar(int V[], int n) {
  int x, comp = 0, mov = 0;
  for (int i = 2; i <= n; i++){
    for(int j = n; j >= i; j--) {
      comp++;
      if(V[j-1] > V[j]){
        x = V[j-1];
        mov++;
        V[j-1] = V[j];
        mov++;
        V[j] = x;
        mov++;
      }
    }
  }
  FILE *file;
  file = fopen("./resultados_bolha.csv", "a");
  fprintf(file, "%d,%d,%d\n", n ,comp, mov);
  fclose(file);
}