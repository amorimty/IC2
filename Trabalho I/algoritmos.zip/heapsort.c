#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void heapify(int V[], int L, int R, int *comp, int *mov);
void ordenar(int V[], int n, int *comp, int *mov);


void main (){
  int n, *V, comp = 0, mov = 0;

  printf("Informe quantos números deseja inserir\n");
  scanf(" %d", &n);
  V = (int *)malloc((n+1) * sizeof(int));
  V[0] = INT_MIN;

  for (int i = 1; i <= n; i++) {
    printf("Entre com um número:\n");
    scanf(" %d", &V[i]);
  }

  ordenar(V, n, &comp, &mov);
  FILE *file;
  file = fopen("./resultados_heapsort.csv", "a");
  fprintf(file, "%d,%d,%d\n", n,comp, mov);
  fclose(file);
  printf("END\n");

}

void heapify(int V[], int L, int R, int *comp, int *mov) {
  int i, j, x;
  i = L;
  j = 2*L;
  x = V[L];
  *mov += 1;
  *comp += 1;
  if ((j< R) && (V[j] < V[j+1]))
    j++;
  *comp += 1;
  while ((j <= R) && x < V[j]) {
    V[i] = V[j];
    *mov += 1;
    i = j;
    j *= 2;
    *comp += 1;
    if ((j< R) && (V[j] < V[j+1]))
      j++;
  }
  V[i] = x;
  *mov += 1;
}

void ordenar(int V[], int n, int *comp, int *mov) {
  int w;
  for (int i = n/2; i >= 1; i--)
    heapify(V, i, n, comp, mov);
  for (int i = n; i >= 2; i--) {
    w = V[1];
    *mov += 1;
    V[1] = V[i];
    *mov += 1;
    V[i] = w;
    *mov += 1;
    heapify(V, 1, i-1, comp, mov);
  }
}



