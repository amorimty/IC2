#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void fundir(int V[], int L, int h, int R, int F[], int *comp, int *mov);
void passagem(int V[], int n, int p, int F[], int *comp, int *mov);
void ordenar(int V[], int n, int F[], int *comp, int *mov);

void main() {
  int n, *V, *F, comp = 0, mov = 0;

  printf("Informe quantos números deseja inserir\n");
  scanf(" %d", &n);
  V = (int *)malloc((n+1) * sizeof(int));
  F = (int *)malloc((n+1) * sizeof(int));
  V[0] = INT_MIN;
  F[0] = INT_MIN;

  for (int i = 1; i <= n; i++) {
    printf("Entre com um número:\n");
    scanf(" %d", &V[i]);
  }

  ordenar(V, n, F, &comp, &mov);
  FILE *file;
  file = fopen("./resultados_fusao.csv", "a");
  fprintf(file, "%d,%d,%d\n", n,comp, mov);
  fclose(file);
  printf("END\n");
}

void fundir(int V[], int L, int h, int R, int F[], int *comp, int *mov) {
  int i = L, j = h+1, k = L-1;

  while (i <= h && j <= R) {
    k++;
    *comp += 1;
    *mov += 1;
    if (V[i] < V[j]){
      F[k] = V[i];
      i++;
    } else {
      F[k] = V[j];
      j++;
    }
  }
  while (i <= h){
    k++;
    F[k] = V[i];
    *mov += 1;
    i++;
  }
  while (j <= R)
  {
    k++;
    F[k] = V[j];
    *mov += 1;
    j++;
  }

}

void passagem(int V[], int n, int p, int F[], int *comp, int *mov) {
  int i = 1;
  while (i <= n-(2*p)+1)
  {
    fundir(V, i, i+p-1, i+2*p-1, F, comp, mov);
    i = i + 2 * p;
  }
  if (i+p-1 < n) {
    fundir(V, i, i+p-1, n, F, comp, mov);
  } else {
    for (int j = i; j <= n; j++)
    {
      F[j] = V[j];
      *mov += 1;
    }
  }
}



void ordenar(int V[], int n, int F[], int *comp, int *mov) {
  int p = 1;
  while (p < n) {
    passagem(V, n, p, F, comp, mov);
    p *= 2;
    passagem(F, n, p, V, comp, mov);
    p *= 2;
  }

}