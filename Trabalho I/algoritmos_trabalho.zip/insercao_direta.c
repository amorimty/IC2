#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <limits.h>

void ordenar(int V[], int n);

void main() {
  int n, *V;


  printf("Informe quantos números deseja inserir\n");
  scanf(" %d", &n);
  V = (int *)malloc((n+1) * sizeof(int));
  V[0] = INT_MIN;

  for (int i = 1; i <= n; i++) {
    printf("Entre com um número:\n");
    scanf(" %d", &V[i]);
  }

  ordenar(V, n);
  printf("END\n");


}

void ordenar(int V[], int n) {
  int x, j, mov = 0, comp = 0;
  for (int i = 2; i <= n;  i++) {
    x = V[i];
    mov++;
    V[0] = x;
    mov++;
    j = i;
    comp++;
    while(x < V[j-1]) {
      comp++;
      V[j] = V[j-1];
      mov++;
      j = j-1;
    }
    V[j] =  x;
    mov++;
  }
  FILE *file;
  file = fopen("./resultados_insercao_direta.csv", "a");
  fprintf(file, "%d,%d,%d\n", n,comp, mov);
  fclose(file);
}