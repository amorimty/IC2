#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void ordenar(int V[], int n);

void main() {
  int n, *V;

  printf("Informe quantos números deseja inserir\n");
  scanf(" %d", &n);
  V = (int *)malloc((n+1) * sizeof(int));
  V[0] = INT_MIN;

  for (int i = 1; i <= n; i++) {
    printf("Entre com um número:\n");
    scanf(" %d", &V[i]);
  }

  ordenar(V, n);
  printf("END\n");

}

void ordenar(int V[], int n) {
 int indice_menor, x, mov = 0, comp = 0;
  for (int i = 1; i <= n -1; i++){
    indice_menor = i;
    for(int j = i+1; j <= n; j++) {
      comp++;
      if(V[j] < V[indice_menor])
        indice_menor = j;
    }
    x = V[i];
    mov++;
    V[i] = V[indice_menor];
    mov++;
    V[indice_menor] = x;
    mov++;
  }
  FILE *file;
  file = fopen("./resultados_selecao.csv", "a");
  fprintf(file, "%d,%d,%d\n", n,comp, mov);
  fclose(file);
}