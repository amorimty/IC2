import pexpect
import numpy

def gerarVetorAleatorio(tamanho):
  V = []
  for i in range(0, tamanho):
    V.append(numpy.random.randint(1, 10000))
  return V

def executar (V, length):
  child.expect('Informe quantos números deseja inserir')
  child.sendline(str(length))
  for x in V:
    child.expect('Entre com um número:')
    child.sendline(str(x))
  child.expect('END')

algoritmos = ['insercao_direta', 'insercao_binaria', 'selecao', 'bolha', 'fusao', 'quicksort', 'heapsort']

for i in range(100, 1500, 100):
  vetorGerado = gerarVetorAleatorio(i)
  print(i)
  for alg in algoritmos:
    V = vetorGerado.copy()
    print(V)
    child = pexpect.spawn('./' + alg,  encoding='utf-8')
    executar(V, i)
    child.close()
    V.sort()
    child = pexpect.spawn('./' + alg,  encoding='utf-8')
    executar(V, i)
    child.close()
    V.sort(reverse=True)
    print(V)
    child = pexpect.spawn('./' + alg,  encoding='utf-8')
    executar(V, i)
    child.close()

