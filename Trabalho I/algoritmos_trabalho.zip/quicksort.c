#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void ordenar(int V[], int n,  int *comp, int *mov);
void ordRapida(int V[], int L, int R,  int *comp, int *mov);

void main() {
  int n, *V, comp = 0, mov = 0;

  printf("Informe quantos números deseja inserir\n");
  scanf(" %d", &n);
  V = (int *)malloc((n+1) * sizeof(int));
  V[0] = INT_MIN;

  for (int i = 1; i <= n; i++) {
    printf("Entre com um número:\n");
    scanf(" %d", &V[i]);
  }
  ordenar(V, n, &comp, &mov);

  FILE *file;
  file = fopen("./resultados_quicksort.csv", "a");
  fprintf(file, "%d,%d,%d\n", n ,comp, mov);
  fclose(file);
  printf("END\n");

}

void ordenar(int V[], int n,  int *comp, int *mov) {
  ordRapida(V, 1, n, comp, mov);
}

void ordRapida(int V[], int L, int R,  int *comp, int *mov) {
  int i = L, j = R, x = V[(L+R)/2], w;
    *mov += 1;

  do {
    *comp += 1;
    while (V[i] < x)
    {
      *comp += 1;
      i++;
    }
    *comp += 1;
    while (x < V[j])
    {
      *comp += 1;
      j--;
    }
    if (i <= j) {
      w = V[i];
      *mov += 1;
      V[i] = V[j];
      *mov += 1;
      V[j] = w;
      *mov += 1;
      i++;
      j--;
    }
  } while (i <= j);
  if (L < j)
    ordRapida(V, L, j, comp, mov);
  if (i < R)
    ordRapida(V, i, R, comp, mov);

}
